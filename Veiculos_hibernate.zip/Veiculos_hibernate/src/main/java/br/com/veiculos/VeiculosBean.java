package br.com.veiculos;


import javax.faces.bean.ManagedBean;


@ManagedBean(name = "veiculosBean")
public class VeiculosBean {
		
		public VeiculosBean() {
			setVeiculo(new Veiculos());
		}

		public Veiculos veiculo;
		
		public Veiculos getVeiculo() {
			return veiculo;
		}
		public void setVeiculo(Veiculos veiculo) {
			this.veiculo = veiculo;
		}
		public String inserirVeiculo() {
			VeiculosDAO veiculosDAO = new VeiculosDAO();
			veiculosDAO.incluirVeiculo(getVeiculo());
			return "";
		}
		

	}
