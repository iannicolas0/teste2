package br.com.veiculos;


import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;





public class VeiculosDAO {

	public void incluirVeiculo(Veiculos veiculo) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("veiculos_hibernate");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		 
		entityManager.getTransaction().begin();		
		entityManager.persist(veiculo);
		entityManager.getTransaction().commit();
		entityManager.close();
		entityManagerFactory.close();
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Dados Gravados com Sucesso :)"));		
	}
	
}
